# okg_self_micro fixture
