# Usage

Call `okg_micro.core.hello("world")` to get a greeting.

## Formal mode

Pass `formal=True` for "Greetings, X." style.
