"""Greeting helpers."""

def hello(name: str, *, formal: bool = False) -> str:
    if formal:
        return f"Greetings, {name}."
    return f"hello, {name}"
