"""okg_self_micro test fixture."""
__version__ = "0.0.1"
